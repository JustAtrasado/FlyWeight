public class Cor {
}
